<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliveredProduct extends Model {

	//

}
