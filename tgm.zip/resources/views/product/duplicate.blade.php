@extends('app')

@section('products') active @endsection

@section('title') TGM - Duplicate Product  @endsection

@section('content')

<div class="container">
    <div class="alert alert-danger col-md-8">
        <strong>Ooops!</strong> Product Already Exist!
    </div>
</div>

@endsection