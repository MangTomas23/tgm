@extends('app')

@section('home') active @endsection

@section('title') TGM - Home @endsection

@section('content')

<div class="container">
    <div class="page-header">
        <h2>Mission</h2>
    </div>

    <blockquote>
        We are committed in the pursuit of producing innovative and quality 
        products with range and affordability in mind for the consumers as 
        well as building strong and trusted business foundation for the 
        benefit of the stakeholders.
    </blockquote>
    
    <div class="page-header">
        <h2>Vision</h2>
    </div>

    <blockquote>
        Our Vision is for everyone to be able to afford the good things in 
        life range, quality and price.
    </blockquote>

    <hr>

    <div class="page-header">
        <h3>Best Selling Product</h3>
    </div>

</div>

@endsection
